// ===================================
// ConFluent v3.2 — OPTIMIZED TRANSLATION ENGINE
// Batch Translation + Conversation Mode
// Performance Tuned + Const Correct
// ===================================

(function () {
  'use strict';

  // === SINGLETON GUARD & IFRAME BLOCK ===
  if (window.self !== window.top) return; // Prevent running in iframes
  if (window.__confluentRunning) return;
  window.__confluentRunning = true;

  // === DEBUG FLAG (set to false for production) ===
  const DEBUG = false;

  if (DEBUG) console.log('%c🌐 ConFluent v3.2', 'background: #000; color: white; padding: 6px 12px; border-radius: 999px;');

  // === WEB AUTH LISTENER ===
  // Listens for login data from confluents.xyz login page
  let authReceived = false;
  window.addEventListener('message', (event) => {
    if (event.origin !== 'https://www.confluents.xyz' && event.origin !== 'https://confluents.xyz') return;
    if (event.data?.type === 'CONFLUENT_AUTH' && !authReceived) {
      const user = event.data.user;
      const settings = event.data.settings;
      if (user && user.email) {
        authReceived = true;
        const storageData = { user };
        if (settings) {
          Object.assign(storageData, settings);
        }

        chrome.storage.local.set(storageData, () => {
          if (DEBUG) console.log('🔐 ConFluent: Logged in and synced as', user.name);
          // Tell the page we got the data
          window.postMessage({ type: 'CONFLUENT_AUTH_OK' }, event.origin);
        });
      }
    }
  });

  // === STATE ===
  let isEnabled = true;
  let isTranslating = false;
  let isReplacing = false; // Guard: true while we are pasting translated text
  let isDeleting = false;
  let typingTimer = null;
  let originalText = '';
  let lastTranslated = '';
  let lastInputTime = 0;
  let translationGeneration = 0; // Stale callback guard

  // Conversation Mode State
  let observer = null;
  const processedNodes = new WeakSet();
  const translatedMap = new WeakMap();

  // Batching
  const batchQueue = [];
  let batchTimer = null;
  const BATCH_DELAY = 100;
  const MAX_BATCH_SIZE = 50;

  // Config
  const settings = {
    delay: 1000,
    targetLang: 'en',
    triggerMode: 'timer',
    conversationMode: false,
    myLang: 'fr',
    theme: 'light'
  };

  // === PLATFORM DETECTION ===
  const IS_MAC = /Mac/.test(navigator.userAgent);

  // === INJECTED STYLES ===
  const style = document.createElement('style');
  style.id = 'tr-styles';
  style.textContent = `
    @keyframes tr-fade-in { from { opacity: 0; transform: scale(0.8) translateY(10px); } to { opacity: 1; transform: scale(1) translateY(0); } }
    @keyframes tr-pulse-violet { 0% { box-shadow: 0 10px 30px -10px rgba(139, 92, 246, 0.3), inset 0 0 0 0 rgba(139, 92, 246, 0); } 50% { box-shadow: 0 10px 40px -5px rgba(139, 92, 246, 0.5), inset 0 0 20px rgba(139, 92, 246, 0.1); } 100% { box-shadow: 0 10px 30px -10px rgba(139, 92, 246, 0.3), inset 0 0 0 0 rgba(139, 92, 246, 0); } }
    @keyframes tr-spin-subtle { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }

    #tr-badge {
      all: initial !important;
      position: fixed !important;
      bottom: 30px !important;
      right: 30px !important;
      width: 56px !important;
      height: 56px !important;
      border-radius: 50% !important;
      display: flex !important;
      align-items: center !important;
      justify-content: center !important;
      cursor: pointer !important;
      z-index: 2147483647 !important;
      user-select: none !important;
      transition: transform 0.4s cubic-bezier(0.34, 1.56, 0.64, 1), box-shadow 0.4s ease !important;
      animation: tr-fade-in 0.6s cubic-bezier(0.16, 1, 0.3, 1) !important;

      background: var(--tr-orb-bg, radial-gradient(120% 120% at 30% 30%, #ffffff 0%, #f8fafc 40%, #e2e8f0 100%)) !important;
      box-shadow: var(--tr-orb-shadow,
        inset 2px 2px 5px rgba(255, 255, 255, 1),
        inset -5px -5px 15px rgba(148, 163, 184, 0.3),
        0 15px 35px -10px rgba(15, 23, 42, 0.2),
        0 5px 15px -5px rgba(15, 23, 42, 0.1)) !important;
      border: var(--tr-orb-border, 1px solid rgba(255, 255, 255, 0.4)) !important;
    }

    #tr-badge:hover {
      transform: scale(1.08) translateY(-4px) !important;
      box-shadow:
        inset 2px 2px 5px rgba(255, 255, 255, 1),
        inset -5px -5px 15px rgba(148, 163, 184, 0.3),
        0 25px 45px -12px rgba(15, 23, 42, 0.25),
        0 10px 20px -8px rgba(15, 23, 42, 0.15) !important;
    }

    #tr-badge:active { transform: scale(0.96) translateY(0) !important; }

    #tr-icon {
      width: 26px !important;
      height: 26px !important;
      color: #94a3b8 !important;
      filter: drop-shadow(0 1px 0 rgba(255,255,255,0.8)) drop-shadow(0 -1px 0 rgba(0,0,0,0.15)) !important;
      transition: color 0.4s ease, filter 0.4s ease, transform 0.4s ease !important;
      opacity: 0.8 !important;
    }

    /* STATES */
    #tr-badge.state-on {
       box-shadow:
        inset 2px 2px 5px rgba(255, 255, 255, 1),
        inset -5px -5px 15px rgba(148, 163, 184, 0.2),
        0 15px 35px -10px rgba(16, 185, 129, 0.3),
        0 5px 15px -5px rgba(16, 185, 129, 0.2) !important;
    }
    #tr-badge.state-on #tr-icon {
      color: #10b981 !important;
      filter: drop-shadow(0 1px 0 rgba(255,255,255,0.9)) drop-shadow(0 0 8px rgba(16, 185, 129, 0.4)) !important;
      opacity: 1 !important;
    }

    #tr-badge.state-off {
      background: radial-gradient(120% 120% at 30% 30%, #f1f5f9 0%, #e2e8f0 100%) !important;
      box-shadow:
        inset 1px 1px 3px rgba(255, 255, 255, 0.8),
        inset -2px -2px 8px rgba(148, 163, 184, 0.2),
        0 10px 25px -8px rgba(15, 23, 42, 0.15) !important;
    }
    #tr-badge.state-off #tr-icon {
      color: #ef4444 !important;
      opacity: 0.5 !important;
      filter: grayscale(0.5) !important;
    }

    #tr-badge.state-working {
      animation: tr-pulse-violet 2.5s infinite ease-in-out !important;
      background: radial-gradient(120% 120% at 30% 30%, #ffffff 0%, #fdf4ff 40%, #f3e8ff 100%) !important;
    }
    #tr-badge.state-working #tr-icon {
      color: #8b5cf6 !important;
      filter: drop-shadow(0 0 12px rgba(139, 92, 246, 0.6)) !important;
      opacity: 1 !important;
    }

    #tr-badge.state-error {
      animation: shake 0.4s cubic-bezier(.36,.07,.19,.97) both !important;
      box-shadow:
        inset 2px 2px 5px rgba(255, 255, 255, 1),
        0 0 0 2px rgba(249, 115, 22, 0.8),
        0 15px 35px -10px rgba(249, 115, 22, 0.4) !important;
    }
    #tr-badge.state-error #tr-icon {
      color: #f97316 !important;
    }

    @keyframes shake { 10%, 90% { transform: translate3d(-1px, 0, 0); } 20%, 80% { transform: translate3d(2px, 0, 0); } 30%, 50%, 70% { transform: translate3d(-4px, 0, 0); } 40%, 60% { transform: translate3d(4px, 0, 0); } }

    /* === DARK MODE === */
    #tr-badge.tr-dark-mode,
    #tr-badge.tr-dark-mode.state-on,
    #tr-badge.tr-dark-mode.state-off,
    #tr-badge.tr-dark-mode.state-working,
    #tr-badge.tr-dark-mode.state-error,
    #tr-badge.tr-dark-mode:hover {
        background: #131215 !important;
        box-shadow: none !important;
        border: none !important;
        animation: none !important;
    }

    #tr-badge.tr-dark-mode.state-working {
        animation: tr-pulse-violet 2.5s infinite ease-in-out !important;
    }

    #tr-badge.tr-dark-mode #tr-icon {
        color: #e2e8f0 !important;
        filter: none !important;
        opacity: 0.9 !important;
    }

    #tr-badge.tr-dark-mode.state-off #tr-icon {
        color: #ef4444 !important;
        opacity: 0.6 !important;
    }

    /* === TOOLTIP TRANSLATION === */
    #tr-tooltip-trigger {
      all: initial !important;
      position: absolute !important;
      width: 28px !important;
      height: 28px !important;
      border-radius: 50% !important;
      background: linear-gradient(135deg, #8b5cf6 0%, #6d28d9 100%) !important;
      display: flex !important;
      align-items: center !important;
      justify-content: center !important;
      cursor: pointer !important;
      z-index: 2147483646 !important;
      box-shadow: 0 2px 8px rgba(139, 92, 246, 0.4), 0 0 0 2px rgba(255,255,255,0.9) !important;
      animation: tr-fade-in 0.2s ease-out !important;
      transition: transform 0.15s ease, box-shadow 0.15s ease !important;
      pointer-events: auto !important;
    }
    #tr-tooltip-trigger:hover {
      transform: scale(1.15) !important;
      box-shadow: 0 4px 14px rgba(139, 92, 246, 0.6), 0 0 0 2px rgba(255,255,255,1) !important;
    }
    #tr-tooltip-trigger:active {
      transform: scale(0.95) !important;
    }
    #tr-tooltip-trigger svg {
      width: 14px !important;
      height: 14px !important;
      color: white !important;
      pointer-events: none !important;
    }

    #tr-tooltip-popup {
      all: initial !important;
      position: absolute !important;
      z-index: 2147483646 !important;
      background: #1e1b2e !important;
      border: 1px solid rgba(139, 92, 246, 0.3) !important;
      border-radius: 12px !important;
      padding: 12px 16px !important;
      max-width: 360px !important;
      min-width: 160px !important;
      box-shadow: 0 8px 32px rgba(0,0,0,0.3), 0 0 0 1px rgba(139,92,246,0.15) !important;
      animation: tr-fade-in 0.25s cubic-bezier(0.16, 1, 0.3, 1) !important;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif !important;
      pointer-events: auto !important;
    }

    #tr-tooltip-source {
      display: block !important;
      font-size: 11px !important;
      color: #a78bfa !important;
      margin-bottom: 6px !important;
      font-weight: 500 !important;
      letter-spacing: 0.5px !important;
      text-transform: uppercase !important;
    }

    #tr-tooltip-text {
      display: block !important;
      font-size: 14px !important;
      color: #f1f5f9 !important;
      line-height: 1.5 !important;
      word-break: break-word !important;
    }

    #tr-tooltip-loading {
      display: flex !important;
      align-items: center !important;
      gap: 8px !important;
      color: #a78bfa !important;
      font-size: 13px !important;
    }
    #tr-tooltip-loading .tr-spinner {
      width: 14px !important;
      height: 14px !important;
      border: 2px solid rgba(167, 139, 250, 0.3) !important;
      border-top-color: #a78bfa !important;
      border-radius: 50% !important;
      animation: tr-spin-subtle 0.6s linear infinite !important;
    }

    #tr-tooltip-actions {
      display: flex !important;
      align-items: center !important;
      justify-content: flex-end !important;
      gap: 6px !important;
      margin-top: 8px !important;
      padding-top: 8px !important;
      border-top: 1px solid rgba(139, 92, 246, 0.15) !important;
    }
    .tr-tooltip-btn {
      all: initial !important;
      display: inline-flex !important;
      align-items: center !important;
      gap: 4px !important;
      padding: 4px 10px !important;
      border-radius: 6px !important;
      font-size: 11px !important;
      font-weight: 600 !important;
      cursor: pointer !important;
      transition: all 0.15s ease !important;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif !important;
    }
    .tr-tooltip-btn.tr-copy {
      background: rgba(139, 92, 246, 0.15) !important;
      color: #c4b5fd !important;
      border: 1px solid rgba(139, 92, 246, 0.2) !important;
    }
    .tr-tooltip-btn.tr-copy:hover {
      background: rgba(139, 92, 246, 0.3) !important;
      color: #ede9fe !important;
    }
    .tr-tooltip-btn.tr-copy.tr-copied {
      background: rgba(16, 185, 129, 0.2) !important;
      color: #6ee7b7 !important;
      border-color: rgba(16, 185, 129, 0.3) !important;
    }
  `;

  // === BADGE ===
  const oldBadge = document.getElementById('tr-badge');
  if (oldBadge) oldBadge.remove();

  const badge = document.createElement('div');
  badge.id = 'tr-badge';
  badge.innerHTML = `
    <svg id="tr-icon" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
      <path fill-rule="evenodd" clip-rule="evenodd" d="M14.5 7.5C15.8807 7.5 17 8.61929 17 10C17 11.3807 15.8807 12.5 14.5 12.5C13.1193 12.5 12 11.3807 12 10C12 8.61929 13.1193 7.5 14.5 7.5ZM9.5 7.5C10.8807 7.5 12 8.61929 12 10C12 11.3807 10.8807 12.5 9.5 12.5C8.11929 12.5 7 11.3807 7 10C7 8.61929 8.11929 7.5 9.5 7.5ZM14.5 5.5C12.756 5.5 11.129 6.275 10 7.545C8.871 6.275 7.244 5.5 5.5 5.5C2.462 5.5 0 7.962 0 11C0 14.038 2.462 16.5 5.5 16.5C7.244 16.5 8.871 15.725 10 14.455C11.129 15.725 12.756 16.5 14.5 16.5C17.538 16.5 20 14.038 20 11C20 7.962 17.538 5.5 14.5 5.5Z" />
    </svg>
  `;

  // === BADGE UI ===
  const BADGE_STATES = ['state-on', 'state-off', 'state-typing', 'state-working', 'state-waiting', 'state-done', 'state-error'];
  const WORKING_STATES = new Set(['typing', 'working', 'waiting']);

  function updateBadgeUI(state, text) {
    if (!badge?.isConnected) return;
    badge.classList.remove(...BADGE_STATES);

    // Hide sphere when disabled, show when active
    if (state === 'off') {
      badge.style.setProperty('display', 'none', 'important');
    } else {
      badge.style.setProperty('display', 'flex', 'important');
    }

    if (WORKING_STATES.has(state)) {
      badge.classList.add('state-working');
      badge.title = text || 'Translating...';
    } else if (state === 'done') {
      badge.classList.add('state-on');
      badge.title = 'Ready';
    } else {
      badge.classList.add(`state-${state}`);
      badge.title = state === 'on' ? 'Ready' : 'Disabled';
    }
  }

  function updateTheme(theme) {
    if (!badge) return;
    if (theme === 'dark') {
      badge.classList.add('tr-dark-mode');
    } else {
      badge.classList.remove('tr-dark-mode');
      badge.style.removeProperty('--tr-orb-bg');
      badge.style.removeProperty('--tr-orb-shadow');
      badge.style.removeProperty('--tr-orb-border');
    }
  }

  function toggle() {
    isEnabled = !isEnabled;
    updateBadgeUI(isEnabled ? 'on' : 'off');
    chrome.storage.local.set({ enabled: isEnabled });
  }

  badge.ondblclick = (e) => {
    e.preventDefault();
    toggle();
  };

  // === INPUT FIELD DETECTION ===
  function getDeepActiveElement(root = document) {
    let activeEl = root.activeElement;
    while (activeEl && activeEl.shadowRoot && activeEl.shadowRoot.activeElement) {
      activeEl = activeEl.shadowRoot.activeElement;
    }
    return activeEl;
  }

  function findActiveEditor() {
    const a = getDeepActiveElement();
    if (a) {
      if (a.tagName === 'INPUT' || a.tagName === 'TEXTAREA') return a;
      const editor = a.closest('[data-slate-editor="true"]')
        || a.closest('[contenteditable="true"]')
        || a.closest('[role="textbox"]')
        || a.closest('.ProseMirror');
      if (editor) return editor;
    }

    // Fallback: Selection API (critical for Discord)
    const sel = window.getSelection();
    if (sel?.anchorNode) {
      const node = sel.anchorNode.nodeType === 3 ? sel.anchorNode.parentNode : sel.anchorNode;
      const editor = node.closest('[data-slate-editor="true"]')
        || node.closest('[contenteditable="true"]')
        || node.closest('[role="textbox"]')
        || node.closest('.ProseMirror');
      if (editor) return editor;
    }

    return null;
  }

  function getText(el) {
    if (!el) return '';
    try {
      if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') return el.value;
      // Rich text: prefer innerText, fallback to textContent
      const txt = el.innerText || el.textContent || '';
      return txt.replace(/\u200B/g, ''); // Remove zero-width spaces
    } catch { return ''; }
  }

  // === HIGH FIDELITY TEXT REPLACEMENT ===
  function createKeyEvent(type, key, code, keyCode) {
    return new KeyboardEvent(type, {
      key, code, keyCode, which: keyCode,
      bubbles: true, cancelable: true, composed: true,
      ctrlKey: !IS_MAC, metaKey: IS_MAC, view: window
    });
  }

  async function replaceText(el, newText) {
    isReplacing = true;
    try {
      // 1. Snapshot text before async op
      const preText = getText(el);

      // 2. Write to real clipboard (needed for paste fallback)
      await navigator.clipboard.writeText(newText);

      // 3. Race condition guard: user typed while clipboard was writing?
      if (getText(el) !== preText) {
        if (DEBUG) console.warn('[ConFluent] Paste aborted: user kept typing.');
        return false;
      }

      el.focus();

      if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
        // === STANDARD INPUTS ===
        el.setSelectionRange(0, el.value.length);
        document.execCommand('insertText', false, newText);
        el.setSelectionRange(el.value.length, el.value.length);
      } else {
        // === RICH TEXT EDITORS (Discord/Slate/ProseMirror/WhatsApp) ===
        // To properly replace text in React/Slate without appending, we must:
        // 1. Modify the DOM selection to cover all text.
        // 2. Trigger a KeyboardEvent 'Cmd+A' so framework key-handlers notice.
        // 3. WAIT a micro-tick so the framework's state model syncs the new selection.
        // 4. Dispatch a ClipboardEvent 'paste' which the framework handles natively.

        // Step 1: Force DOM Selection
        document.execCommand('selectAll', false, null);
        document.dispatchEvent(new Event('selectionchange'));

        // Step 2: Push fake keydown so framework event handlers trigger
        el.dispatchEvent(new KeyboardEvent('keydown', {
          key: 'a', code: 'KeyA', keyCode: 65, which: 65,
          ctrlKey: !IS_MAC, metaKey: IS_MAC,
          bubbles: true, cancelable: true, composed: true
        }));

        // Step 3: Crucial delay — let the React/Slate reconciliation engine update its internal selection
        // Since isReplacing is true, the user typing is blocked in our handleInput.
        await new Promise(r => setTimeout(r, 15));

        // Step 4: Dispatch the simulated Paste
        const dt = new DataTransfer();
        dt.setData('text/plain', newText);
        const pasteEvt = new ClipboardEvent('paste', {
          bubbles: true, cancelable: true, composed: true,
          clipboardData: dt, view: window
        });
        el.dispatchEvent(pasteEvt);

        // Fallback if Paste wasn't consumed
        if (!pasteEvt.defaultPrevented) {
          document.execCommand('insertText', false, newText);
        }

        // Force cursor to end
        const endSel = window.getSelection();
        if (endSel) endSel.collapseToEnd();
      }

      // 4. Notify UI frameworks
      el.dispatchEvent(new InputEvent('input', {
        bubbles: true, inputType: 'insertText', data: newText, composed: true
      }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      return true;

    } catch (err) {
      console.warn('[ConFluent] Paste error:', err);
      return false;
    } finally {
      setTimeout(() => { isReplacing = false; }, 100);
    }
  }

  // === TRANSLATION LOGIC ===
  document.addEventListener('keydown', (e) => {
    if (!e.ctrlKey && !e.metaKey && e.key.length === 1) lastInputTime = Date.now();
    if (['Backspace', 'Delete'].includes(e.key)) {
      isDeleting = true;
      clearTimeout(typingTimer);
    }
  }, true);

  function translate(el, text, ignoreGuard = false) {
    if (!text || text.length < 2 || text === lastTranslated) return;
    if (!ignoreGuard && Date.now() - lastInputTime < 50) return;

    isTranslating = true;
    const gen = ++translationGeneration; // Stale guard
    updateBadgeUI('working');

    try {
      // User's outgoing reply language
      const targetLang = settings.targetLang;
      // IMPORTANT: Explicitly set the source language to the user's native language.
      // This prevents the translation engine from getting confused by mixed-language sentences
      // when the user resumes typing after a previous translation.
      const sourceLang = settings.myLang;

      chrome.runtime.sendMessage(
        { action: 'translate', text, targetLang, sourceLang },
        async (res) => {
          try {
            // Discard stale results
            if (gen !== translationGeneration) return;

            if (chrome.runtime.lastError) {
              if (chrome.runtime.lastError.message.includes('context invalidated')) {
                destroy();
                return;
              }
              updateBadgeUI('error');
              setTimeout(() => updateBadgeUI('on'), 2000);
              return;
            }

            if (res?.translation && res.translation.toLowerCase() !== text.toLowerCase()) {
              if (ignoreGuard || (getText(el) === text && Date.now() - lastInputTime > 50)) {
                const pasted = await replaceText(el, res.translation);
                if (pasted) {
                  originalText = res.translation;
                  lastTranslated = res.translation;
                  updateBadgeUI('done');
                } else {
                  // Paste aborted
                  updateBadgeUI('on');
                }
              } else {
                updateBadgeUI('on');
              }
            } else {
              updateBadgeUI('on');
            }
          } finally {
            if (gen === translationGeneration) {
              isTranslating = false;
            }
          }
        }
      );
    } catch {
      isTranslating = false;
      destroy();
    }
  }

  // === UNIFIED INPUT HANDLER ===
  function handleInput() {
    if (!isEnabled || isReplacing) return;
    lastInputTime = Date.now();
    const el = findActiveEditor();
    if (!el) return;
    const rawText = getText(el);
    const currentText = rawText.trim();

    if (isDeleting) { isDeleting = false; originalText = currentText; return; }
    if (currentText.length < originalText.length) { originalText = currentText; clearTimeout(typingTimer); return; }
    if (currentText.length === 0) { originalText = ''; lastTranslated = ''; clearTimeout(typingTimer); return; }

    if (currentText !== lastTranslated && currentText.length >= 2) {
      updateBadgeUI('typing');
      clearTimeout(typingTimer);

      const mode = settings.triggerMode || 'timer';

      if (mode === 'space') {
        // Double spacebar: check the RAW (untrimmed) text for trailing double space
        if (rawText.endsWith('  ')) {
          translate(el, currentText, true);
        }
        // Otherwise do nothing — wait for the user to double-space
      } else {
        // Timer mode (default: standard 1s)
        typingTimer = setTimeout(() => translate(el, currentText), 1000);
      }
    }
  }

  // Single unified listener (no duplicate keyup handler)
  document.addEventListener('input', handleInput, true);
  document.addEventListener('keyup', (e) => {
    // Only handle printable keys as fallback for editors that suppress 'input'
    if (e.key.length !== 1 || e.ctrlKey || e.metaKey || e.altKey) return;
    handleInput();
  }, true);

  // Track focus changes to reset originalText
  const resetOriginal = () => {
    setTimeout(() => {
      const el = findActiveEditor();
      if (el) originalText = getText(el);
    }, 100);
  };
  document.addEventListener('click', resetOriginal, true);
  document.addEventListener('focus', resetOriginal, true);

  // === CONVERSATION MODE ===

  function startConversationMode() {
    if (observer) observer.disconnect();

    if (DEBUG) console.log('🗣️ Conversation Mode ON: Reading in', settings.myLang);
    updateBadgeUI('on');

    let mutationQueue = [];
    let mutationTimer = null;

    observer = new MutationObserver(mutations => {
      if (!isEnabled || !settings.conversationMode) return;

      let hasNew = false;
      for (const m of mutations) {
        if (m.type === 'childList') {
          for (const n of m.addedNodes) {
            mutationQueue.push(n);
            hasNew = true;
          }
        }
      }
      if (!hasNew) return;

      clearTimeout(mutationTimer);
      mutationTimer = setTimeout(() => {
        const nodes = mutationQueue.splice(0);
        for (const node of nodes) walkAndQueue(node);
      }, 500);
    });

    observer.observe(document.body, { childList: true, subtree: true });

    // Scan existing content immediately
    setTimeout(() => walkAndQueue(document.body), 100);
  }

  function stopConversationMode() {
    if (observer) {
      observer.disconnect();
      observer = null;
    }
    if (DEBUG) console.log('🗣️ Conversation Mode OFF');
  }

  // === BATCH TRANSLATION ===
  const BATCH_DELIMITER = '\n\n====B====\n\n';

  function flushBatch() {
    if (batchQueue.length === 0) return;

    const batch = batchQueue.splice(0, MAX_BATCH_SIZE);
    const hugeText = batch.map(item => item.text).join(BATCH_DELIMITER);

    updateBadgeUI('working', 'Translating incoming...');

    chrome.runtime.sendMessage({
      action: 'translate',
      text: hugeText,
      targetLang: settings.myLang,
    }, (res) => {
      updateBadgeUI('on');
      if (chrome.runtime.lastError || !res?.translation) return;

      const parts = res.translation.split(new RegExp(BATCH_DELIMITER.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')));
      batch.forEach((item, i) => {
        const translation = parts[i]?.trim();
        if (translation?.length > 0) {
          item.node.nodeValue = translation;
          translatedMap.set(item.node, translation);
        }
      });
    });
  }

  function queueNodeForTranslation(node, text) {
    batchQueue.push({ node, text });
    clearTimeout(batchTimer);

    if (batchQueue.length >= MAX_BATCH_SIZE) {
      flushBatch();
    } else {
      batchTimer = setTimeout(flushBatch, BATCH_DELAY);
    }
  }

  // === DOM WALKER (Optimized) ===
  const SKIP_TAGS = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'TEXTAREA', 'INPUT', 'CODE', 'PRE', 'SVG']);

  function walkAndQueue(rootNode) {
    if (!rootNode) return;

    const root = rootNode.nodeType === Node.ELEMENT_NODE ? rootNode : document.body;

    function isTextNodeValid(node) {
      const parent = node.parentNode;
      if (!parent) return false;
      if (SKIP_TAGS.has(parent.tagName)) return false;
      if (parent.isContentEditable) return false;
      if (parent.closest && parent.closest('[contenteditable="true"]')) return false;
      if (parent.getAttribute?.('translate') === 'no' || parent.classList?.contains('notranslate')) {
        return false;
      }
      return true;
    }

    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        if (!isTextNodeValid(node)) return NodeFilter.FILTER_REJECT;
        const text = node.nodeValue.trim();
        if (text.length < 3 || /^\d+$/.test(text)) return NodeFilter.FILTER_SKIP;
        if (translatedMap.has(node) || processedNodes.has(node)) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });

    if (rootNode.nodeType === Node.TEXT_NODE) {
      if (isTextNodeValid(rootNode) && rootNode.nodeValue.trim().length >= 3 && !processedNodes.has(rootNode)) {
        processedNodes.add(rootNode);
        queueNodeForTranslation(rootNode, rootNode.nodeValue.trim());
      }
    } else {
      let current;
      while ((current = walker.nextNode())) {
        processedNodes.add(current);
        queueNodeForTranslation(current, current.nodeValue.trim());
      }
    }
  }


  // === TOOLTIP TRANSLATION ===
  let tooltipTrigger = null;
  let tooltipPopup = null;

  const TRANSLATE_ICON_SVG = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 8l6 6"/><path d="M4 14l6-6 2-3"/><path d="M2 5h12"/><path d="M7 2h1"/><path d="M22 22l-5-10-5 10"/><path d="M14 18h6"/></svg>`;

  function removeTooltipTrigger() {
    if (tooltipTrigger) { tooltipTrigger.remove(); tooltipTrigger = null; }
  }

  function removeTooltipPopup() {
    if (tooltipPopup) { tooltipPopup.remove(); tooltipPopup = null; }
  }

  function removeAllTooltips() {
    removeTooltipTrigger();
    removeTooltipPopup();
  }

  function showTooltipTrigger(x, y, selectedText) {
    removeAllTooltips();

    const trigger = document.createElement('div');
    trigger.id = 'tr-tooltip-trigger';
    trigger.innerHTML = TRANSLATE_ICON_SVG;
    trigger.style.left = `${x + 6}px`;
    trigger.style.top = `${y - 36}px`;

    trigger.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      showTooltipPopup(x, y, selectedText);
    });

    document.body.appendChild(trigger);
    tooltipTrigger = trigger;
  }

  function showTooltipPopup(x, y, selectedText) {
    removeTooltipTrigger();
    removeTooltipPopup();

    const popup = document.createElement('div');
    popup.id = 'tr-tooltip-popup';
    popup.innerHTML = `
      <span id="tr-tooltip-source">Translation</span>
      <div id="tr-tooltip-loading">
        <div class="tr-spinner"></div>
        <span>Translating...</span>
      </div>
    `;

    // Position: try above selection, fall back to below
    const viewW = window.innerWidth;
    const viewH = window.innerHeight;
    let left = x;
    let top = y - 90;

    // Clamp horizontal
    if (left + 360 > viewW) left = viewW - 375;
    if (left < 10) left = 10;
    // If too close to top, show below selection
    if (top < 10) top = y + 25;

    popup.style.left = `${left}px`;
    popup.style.top = `${top}px`;

    document.body.appendChild(popup);
    tooltipPopup = popup;

    // Translate via background
    try {
      chrome.runtime.sendMessage(
        { action: 'translate', text: selectedText, targetLang: settings.myLang || 'fr', isIncoming: true },
        (res) => {
          if (!tooltipPopup || !tooltipPopup.isConnected) return;
          if (chrome.runtime.lastError || !res?.translation) {
            tooltipPopup.innerHTML = `
              <span id="tr-tooltip-source">Error</span>
              <span id="tr-tooltip-text" style="color: #f87171 !important;">Translation failed</span>
            `;
            return;
          }
          tooltipPopup.innerHTML = `
            <span id="tr-tooltip-source">Translation</span>
            <span id="tr-tooltip-text">${res.translation.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</span>
            <div id="tr-tooltip-actions">
              <button class="tr-tooltip-btn tr-copy" id="tr-tooltip-copy">📋 Copy</button>
            </div>
          `;
          // Readjust position after content loaded
          const rect = tooltipPopup.getBoundingClientRect();
          if (rect.right > viewW) {
            tooltipPopup.style.left = `${viewW - rect.width - 15}px`;
          }
          if (rect.bottom > viewH) {
            tooltipPopup.style.top = `${y - rect.height - 10}px`;
          }
          // Copy button handler
          const copyBtn = document.getElementById('tr-tooltip-copy');
          if (copyBtn) {
            copyBtn.addEventListener('click', (e) => {
              e.stopPropagation();
              navigator.clipboard.writeText(res.translation).then(() => {
                copyBtn.textContent = '✓ Copied';
                copyBtn.classList.add('tr-copied');
                setTimeout(() => {
                  if (copyBtn.isConnected) {
                    copyBtn.textContent = '📋 Copy';
                    copyBtn.classList.remove('tr-copied');
                  }
                }, 1500);
              });
            });
          }
        }
      );
    } catch {
      removeTooltipPopup();
    }
  }

  // Selection handler — show tooltip trigger on text selection
  document.addEventListener('mouseup', (e) => {
    // Skip if clicking on tooltip elements
    if (e.target.closest('#tr-tooltip-trigger') || e.target.closest('#tr-tooltip-popup')) return;

    // Small delay to let browser set selection
    setTimeout(() => {
      const sel = window.getSelection();
      const text = sel?.toString().trim();

      if (text && text.length >= 2 && text.length < 2000 && isEnabled) {
        const range = sel.getRangeAt(0);
        const rect = range.getBoundingClientRect();
        const x = rect.right + window.scrollX;
        const y = rect.top + window.scrollY;
        showTooltipTrigger(x, y, text);
      } else {
        removeTooltipTrigger();
      }
    }, 10);
  });

  // Dismiss tooltip on click outside
  document.addEventListener('mousedown', (e) => {
    if (e.target.closest('#tr-tooltip-trigger') || e.target.closest('#tr-tooltip-popup')) return;
    removeAllTooltips();
  });

  // Dismiss on scroll
  window.addEventListener('scroll', removeAllTooltips, { passive: true });

  // Dismiss on Escape
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') removeAllTooltips();
  });


  // === CLEANUP ===
  function destroy() {
    stopConversationMode();
    removeAllTooltips();
    document.removeEventListener('input', handleInput, true);
    badge?.parentNode?.removeChild(badge);
    window.__confluentRunning = false;
  }

  // === CONFIG & MESSAGING ===
  function loadConfig() {
    try {
      chrome.storage.local.get(
        ['delay', 'targetLang', 'enabled', 'triggerMode', 'conversationMode', 'myLang', 'theme'],
        (c) => {
          if (chrome.runtime.lastError || !c) return;

          if (c.delay) settings.delay = parseInt(c.delay);
          if (c.targetLang) settings.targetLang = c.targetLang;
          if (c.triggerMode) settings.triggerMode = c.triggerMode;
          if (c.conversationMode !== undefined) settings.conversationMode = c.conversationMode;
          if (c.myLang) settings.myLang = c.myLang;
          if (c.theme) settings.theme = c.theme;
          if (c.enabled !== undefined) isEnabled = c.enabled;


          updateBadgeUI(isEnabled ? 'on' : 'off');
          updateTheme(settings.theme);

          if (isEnabled && settings.conversationMode) {
            startConversationMode();
          } else {
            stopConversationMode();
          }
        }
      );
    } catch { }
  }

  chrome.runtime.onMessage.addListener((m, _sender, sendResponse) => {
    switch (m.action) {
      case 'ping':
        sendResponse({ status: 'pong', enabled: isEnabled });
        return;

      case 'configChanged': {
        const c = m.config;
        if (c.delay) settings.delay = parseInt(c.delay);
        if (c.targetLang) settings.targetLang = c.targetLang;
        if (c.triggerMode) settings.triggerMode = c.triggerMode;
        if (c.conversationMode !== undefined) settings.conversationMode = c.conversationMode;
        if (c.myLang) settings.myLang = c.myLang;
        if (c.theme) settings.theme = c.theme;
        if (c.enabled !== undefined) isEnabled = c.enabled;


        updateBadgeUI(isEnabled ? 'on' : 'off');
        updateTheme(settings.theme);

        if (isEnabled && settings.conversationMode && !observer) {
          startConversationMode();
        } else if ((!isEnabled || !settings.conversationMode) && observer) {
          stopConversationMode();
        }
        return;
      }

      case 'statusChanged':
        isEnabled = m.enabled;
        updateBadgeUI(isEnabled ? 'on' : 'off');
        if (isEnabled && settings.conversationMode) startConversationMode();
        else stopConversationMode();
        return;

    }
  });

  // === SPA URL CHANGE DETECTION ===
  let lastUrl = location.href;

  function onUrlChange() {
    const currentUrl = location.href;
    if (currentUrl === lastUrl) return;
    lastUrl = currentUrl;

    // Reset translation state
    isTranslating = false;
    originalText = '';
    lastTranslated = '';
    clearTimeout(typingTimer);
    translationGeneration++;

    // Reinitialize conversation mode if active
    if (isEnabled && settings.conversationMode) {
      stopConversationMode();
      setTimeout(() => startConversationMode(), 300);
    }

    updateBadgeUI(isEnabled ? 'on' : 'off');
  }

  // Hook into History API (SPA navigation: Discord, Twitter, WhatsApp Web, etc.)
  const originalPushState = history.pushState;
  const originalReplaceState = history.replaceState;

  history.pushState = function (...args) {
    originalPushState.apply(this, args);
    onUrlChange();
  };

  history.replaceState = function (...args) {
    originalReplaceState.apply(this, args);
    onUrlChange();
  };

  window.addEventListener('popstate', onUrlChange);
  window.addEventListener('hashchange', onUrlChange);

  // === INIT ===
  function init() {
    if (window.self !== window.top) return;

    // Remove any existing badge to prevent duplicates
    const existingBadge = document.getElementById('tr-badge');
    if (existingBadge) existingBadge.remove();

    if (!document.getElementById('tr-styles')) {
      (document.head || document.documentElement).appendChild(style);
    }

    (document.body || document.documentElement).appendChild(badge);
    loadConfig();
    if (DEBUG) console.log('🌐 ConFluent v3.2 | Ready');
  }

  if (document.readyState === 'complete') init();
  else window.addEventListener('load', init);

})();
